from flask import Flask
from api_v1 import api as api_v1
from flask import request
from models import db
import os

app = Flask(__name__)
app.register_blueprint(api_v1 , url_prefix='/api/v1')


basedir = os.path.abspath(os.path.dirname(__file__))
dbfile = os.path.join(basedir, 'db.sqlite')

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + dbfile
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True ## 트렌젝션 하나의 요청을 할때마다 커밋 됨 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False ## 수정사항에 대한 트랜젝션을 하겠다. ( 최신버전에선 러닝 메세지 나오니 설정해주기 )
app.config['SECRET_KEY'] = 'qkwejweijweiojfwejp1ff22f2332efwjo'

db.init_app(app)
db.app = app
db.create_all()

if __name__ == '__main__':
    app.run(host='127.0.0.1' , port=5000 , debug=True)