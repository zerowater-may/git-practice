from flask import jsonify
from flask import request
from flask import Blueprint
from models import Todo, db
import requests,json
from . import api



@api.route('/todos' , methods=['GET','POST'])
def todos():
    if request.method == 'POST':
        res = requests.post('https://hooks.slack.com/services/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', json={'text':'Hello, World!'} , headers={'Content-Type':'application/json'})

    elif request.method == 'GET':
        pass
    
    data = request.get_json()
    return jsonify(data)



@api.route('/slack/todos' , methods=['POST'])
def slack_todos():
    res = request.form['text'].split(' ')
    cmd, *args = res
    if cmd == 'create':
        todo_name = args[0]

        todo = Todo()
        todo.title = todo_name

        db.session.add(todo)
        db.session.commit()
        ret_msg = 'todo가 생성되었습니다.'
    elif cmd == 'list':
        pass
    return jsonify(res)
